
# 1- Imports and NLTK Setup

import nltk
from nltk.sentiment import SentimentIntensityAnalyzer
from nltk.chat.util import Chat, reflections
from flask import Flask, render_template, request

# Download required NLTK data (only first time)
nltk.download('punkt')
nltk.download('vader_lexicon')


# 2- Chatbot Pairs

pairs = [
    # Greetings
    [r"(?i).*assalam.*|.*salam.*|.*hello.*|.*hi.*|.*hey.*",
     ["Wa Alaikum Assalam! How can I assist you with admissions?",
      "Hello! Do you want information about programs or admission?",
      "Hi there! How can I help you with university info?"]],

    [r"(?i).*how are you.*|.*how is it going.*",
     ["I'm just a chatbot, ready to assist you with admissions!",
      "Doing well! How can I help you today?"]],

    # Programs & Courses
    [r"(?i).*programs.*offer.*|.*courses available.*|.*degree programs.*",
     ["Superior University offers undergraduate, graduate, and PhD programs in Engineering, Business, IT, Social Sciences, and more."]],

    [r"(?i).*bs in computer science.*|.*undergraduate cs.*",
     ["The BS in Computer Science program focuses on programming, AI, Data Science, and Software Development."]],

    [r"(?i).*ms in business.*|.*graduate business program.*",
     ["Our MS in Business Administration covers management, finance, marketing, and entrepreneurship."]],

    [r"(?i).*phd in engineering.*|.*doctoral engineering program.*",
     ["The PhD in Engineering focuses on research in Electrical, Mechanical, and Civil Engineering fields."]],

    [r"(?i).*online courses.*|.*distance learning.*|.*virtual programs.*",
     ["Superior University offers select online courses and distance learning programs."]],

    [r"(?i).*part time courses.*|.*evening programs.*",
     ["Yes, we offer part-time and evening programs for working students."]],

    [r"(?i).*specializations.*|.*majors available.*",
     ["Students can specialize in fields such as AI, Data Science, Marketing, Finance, Media Studies, and more."]],

    # Admission Requirements & Process
    [r"(?i).*admission requirements.*|.*eligibility.*|.*entry requirements.*",
     ["Admission requirements vary by program. Generally, you need academic transcripts, an entry test (if applicable), and supporting documents."]],

    [r"(?i).*how.*apply.*|.*admission process.*|.*procedure to apply.*",
     ["You can apply online through the official Superior University website or visit the admission office for assistance."]],

    [r"(?i).*application fee.*|.*how much for applying.*",
     ["The application fee is PKR 3000. Payment can be made online during submission."]],

    [r"(?i).*is admission merit based.*|.*merit criteria.*",
     ["Some programs are purely merit-based, while others consider entry test scores and interviews."]],

    [r"(?i).*sample test papers.*|.*past entry test.*",
     ["Sample entry test papers and previous year questions are available on the official website."]],

    [r"(?i).*interview required.*|.*admission interview.*",
     ["Some programs may require an admission interview. You will be informed after initial screening."]],

    [r"(?i).*documents required.*|.*papers needed.*",
     ["You will need academic transcripts, identification documents, photographs, and any program-specific certificates."]],

    # Deadlines & Application Status
    [r"(?i).*deadline.*|.*last date to apply.*|.*admission closing date.*",
     ["Admission deadlines vary each semester. Please check the official website or contact the admission office for updated information."]],

    [r"(?i).*check application status.*|.*track application.*",
     ["You can track your application status through the university portal or by contacting the admission office."]],

    [r"(?i).*late application.*|.*missed deadline.*",
     ["Late applications may be considered at the discretion of the admission office. Contact them for guidance."]],

    [r"(?i).*defer admission.*|.*postpone admission.*",
     ["Yes, deferral may be allowed. Contact the admissions office with a valid reason."]],

    # Fees & Financial Aid
    [r"(?i).*tuition fees.*|.*fee structure.*",
     ["Tuition fees vary depending on the program. You can check the official website for the detailed fee structure."]],

    [r"(?i).*fees installment.*|.*payment plan.*",
     ["Tuition fees can be paid in installments. Contact the finance office for details."]],

    [r"(?i).*scholarship.*|.*financial aid.*|.*tuition support.*",
     ["Scholarships are offered based on merit, need, sports, and extracurricular excellence."]],

    [r"(?i).*international student fees.*|.*foreign student fee.*",
     ["International student fees vary; please check the admissions page for accurate details."]],

    # Hostel & Campus Facilities
    [r"(?i).*hostel.*|.*accommodation.*|.*on-campus living.*",
     ["Yes, we provide hostel facilities for both male and female students with all necessary amenities."]],

    [r"(?i).*hostel rules.*|.*hostel regulations.*",
     ["Hostel regulations include curfew timings, safety rules, and conduct policies."]],

    [r"(?i).*meal plans.*|.*cafeteria.*|.*hostel food.*",
     ["Hostels provide meal plans including breakfast, lunch, and dinner. Cafeteria services are also available."]],

    [r"(?i).*library.*|.*number of libraries.*|.*library hours.*",
     ["We have multiple libraries across campuses, open Monday to Friday 8 AM - 8 PM, and Saturday 9 AM - 5 PM."]],

    [r"(?i).*sports facilities.*|.*athletics.*",
     ["We host annual sports events including cricket, football, badminton, and more."]],

    [r"(?i).*labs.*|.*research facilities.*",
     ["Students have access to modern labs and research facilities for practical learning."]],

    [r"(?i).*Wi-Fi.*|.*internet on campus.*",
     ["Wi-Fi is available in all campus buildings and libraries for students."]],

    [r"(?i).*transport.*|.*shuttle service.*|.*bus service.*",
     ["University provides shuttle services across campuses and nearby areas."]],

    # Faculty & Departments
    [r"(?i).*faculty.*|.*number of faculty.*|.*teachers.*",
     ["Our university has highly qualified faculty members across all departments. Visit the website for full faculty details."]],

    [r"(?i).*departments.*|.*how many departments.*|.*list of departments.*",
     ["Superior University has departments in Computer Science, Business Administration, Electrical Engineering, Media Studies, Social Sciences, and more."]],

    [r"(?i).*head of department.*|.*hod.*",
     ["You can find Head of Department information on the official website."]],

    # International Students
    [r"(?i).*international students.*|.*foreign students.*|.*apply from abroad.*",
     ["International students are welcome to apply. They must meet eligibility criteria and provide necessary documentation."]],

    [r"(?i).*visa assistance.*|.*study visa support.*",
     ["Our international office provides guidance for study visas and documentation."]],

    [r"(?i).*exchange programs.*|.*study abroad programs.*",
     ["We offer student exchange programs with partner universities abroad."]],

    [r"(?i).*language requirements.*|.*english proficiency.*",
     ["International students must meet English proficiency requirements."]],

    # Career & Placements
    [r"(?i).*career opportunities.*|.*jobs after graduation.*|.*placements.*",
     ["Our graduates have opportunities in national and international companies, research institutes, and entrepreneurship."]],

    [r"(?i).*internship.*|.*practical training.*",
     ["Internships are available in multiple departments and partner companies."]],

    [r"(?i).*entrepreneurship.*|.*startup support.*",
     ["We support student entrepreneurship through workshops and incubator programs."]],

    # Communication & Support
    [r"(?i).*contact admission office.*|.*admission email.*|.*phone number.*",
     ["You can contact the admission office via email, phone, or visit in person. Details are on the website."]],

    [r"(?i).*campus tour.*|.*visit campus.*",
     ["You can schedule a campus tour online or in-person to explore facilities and programs."]],

    [r"(?i).*help desk.*|.*student support.*|.*assistance.*",
     ["You can contact the student support or help desk for guidance regarding admissions, courses, or campus life."]],

    # Miscellaneous / University Info
    [r"(?i).*ranking.*|.*top university.*|.*position in pakistan.*",
     ["Superior University is ranked among the top private universities in Pakistan."]],

    [r"(?i).*unique programs.*|.*what makes uni different.*",
     ["Our university offers industry-aligned programs, state-of-the-art labs, research opportunities, and strong internship support."]],

    [r"(?i).*student life.*|.*campus life.*",
     ["Campus life includes clubs, societies, cultural events, and sports activities."]],

    [r"(?i).*graduation requirements.*|.*degree completion.*",
     ["Requirements for graduation include completing the required credits, courses, and passing final exams."]],

    # Farewell
    [r"(?i).*bye.*|.*goodbye.*|.*see you later.*",
     ["Goodbye! Feel free to ask anytime.",
      "See you later! Good luck with your admission.",
      "Take care! Let us know if you have more questions."]]
]



# 3- Initialize Chatbot and Sentiment Analyzer

chatbot = Chat(pairs, reflections)
sia = SentimentIntensityAnalyzer()


# 4- Flask App Setup

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")  

@app.route("/get")
def get_bot_response():
    user_input = request.args.get('msg')
    response = chatbot.respond(user_input)
    if response:
        return response
    else:
        return "I'm not sure how to respond to that."

# 5- Run Flask App

if __name__ == "__main__":
    app.run(debug=True)
