# 📘 Mini Bot - Intelligent University Assistant

## 🚀 Overview
**Mini Bot** (formerly UniBot) is a hybrid AI assistant designed for universities. It combines **Local NLP** for accurate, instant university-specific answers with **Google Gemini AI** for handling general knowledge queries. It speaks a friendly mix of **Urdu and English (Hinglish)**.

---

## 🛠️ Technology Stack
This project uses the following technologies:

### 1. **Core Backend**
-   **Python**: The main programming language.
-   **Flask**: A lightweight web framework to serve the application.

### 2. **Artificial Intelligence (Hybrid Brain)**
-   **Local NLP (Scikit-Learn)**:
    -   Uses **TF-IDF (Term Frequency-Inverse Document Frequency)** to convert text into numbers.
    -   Uses **Logistic Regression** to classify user intent (e.g., "fees", "admission").
    -   *Why?* Extremely fast and 100% accurate for university-specific questions.
-   **Google Gemini 1.5 Flash (Generative AI)**:
    -   Fallback brain for general questions.
    -   *Why?* Handles complex queries, general knowledge, coding, and casual chit-chat.

### 3. **Database**
-   **SQLite**: A simple, file-based database to store:
    -   Chat history.
    -   Low-confidence queries (for future training).
    -   Feedback.

### 4. **Frontend**
-   **HTML5 / CSS3**: Custom responsive design with specific animations.
-   **JavaScript**: Handles messages and API calls without reloading the page.

---

## 📂 Project Structure
-   `app.py`: The main server file. Handles routing and AI logic.
-   `nlp_model/`:
    -   `train.py`: Script to train the local NLP model.
    -   `predict.py`: Logic to predict intent using the trained model.
    -   `faq_data.csv`: The training dataset (Questions & Intents).
-   `database/`: Contains `unibot.db` (Chat logs).
-   `templates/`: Contains `index.html` (The user interface).
-   `static/`: Contains `style.css` and images.
-   `intents.json`: Configuration file mapping intents to specific bot responses.

---

## ❓ Questions You Can Ask
Mini Bot deals with two types of questions:

### 🏛️ Type 1: University Questions (Local Data)
These are answered instantly using the university's internal data.
-   **Admissions**: "How to apply for admission?", "Last date for admission?"
-   **Fees**: "What is the fee structure?", "Fee per semester?"
-   **Programs**: "Which programs do you offer?", "List all courses."
-   **Hostels**: "Is hostel facility available?", "Hostel fees?"
-   **Contact**: "University contact number?", "Email address?"
-   **Location**: "Where is the university located?"

### 🌍 Type 2: General Questions (Gemini AI)
These are answered by the advanced AI brain.
-   **General Knowledge**: "Who is Einstein?", "What is the capital of France?"
-   **Coding/Tech**: "What is Python?", "Write a hello world code."
-   **Creative**: "Write a poem about university life."
-   **Chit-Chat**: "How are you?", "Tell me a joke."

---

## ⚙️ How to Run
1.  **Start the Server**:
    ```bash
    python app.py
    ```
2.  **Access the Bot**:
    Open your browser and search: `http://127.0.0.1:5000`

## 🔄 How to Retrain
If you add new questions to `faq_data.csv` or responses to `intents.json`:
```bash
python nlp_model/train.py
```
This will update the bot's local brain.
