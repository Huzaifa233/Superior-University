import sqlite3

# Connect to SQLite database (creates file if not exists)
conn = sqlite3.connect('database/unibot.db')
cursor = conn.cursor()

# Create chats table
cursor.execute('''
CREATE TABLE IF NOT EXISTS chats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_input TEXT,
    bot_response TEXT,
    intent TEXT,
    confidence REAL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
)
''')

# Optional: intents table
cursor.execute('''
CREATE TABLE IF NOT EXISTS intents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tag TEXT UNIQUE,
    patterns TEXT,
    responses TEXT
)
''')

cursor.execute('''
CREATE TABLE IF NOT EXISTS low_confidence_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_input TEXT,
    predicted_intent TEXT,
    confidence REAL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
)
''')

conn.commit()
conn.close()
print("Database and tables created successfully!")
