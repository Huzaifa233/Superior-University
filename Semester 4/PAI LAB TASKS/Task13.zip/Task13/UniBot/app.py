import os
import sqlite3
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
import google.generativeai as genai
from nlp_model.predict import predict 
import json
from datetime import datetime

load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
MODEL_NAME = os.getenv("MODEL_NAME", "gemini-1.5-flash")

if not GEMINI_API_KEY:
    raise ValueError("GEMINI_API_KEY not found in .env!")

genai.configure(api_key=GEMINI_API_KEY)


with open("intents.json", "r", encoding="utf-8") as f:
    intents = json.load(f)


app = Flask(__name__)

def check_prerequisites():
    """Check if all required files exist"""
    import os
    
    required_files = [
        ("nlp_model/model.pkl", "NLP model not found. Run: python nlp_model/train.py"),
        ("database/unibot.db", "Database not found. Run: python database/db_setup.py"),
    ]
    
    missing = []
    for file_path, message in required_files:
        if not os.path.exists(file_path):
            missing.append(f"❌ {message}")
    
    if missing:
        print("\n⚠️  Missing Prerequisites:\n")
        for msg in missing:
            print(msg)
        print("\nPlease run the setup commands above before starting the app.\n")
        return False
    
    print("✅ All prerequisites satisfied!")
    return True

def call_gen_ai(user_input):
    """Fallback for low-confidence queries"""
    try:
        model = genai.GenerativeModel(MODEL_NAME)

        prompt = f"""
You are "Mini Bot", a smart and helpful AI assistant.

Your Priorities:
1. **University Queries**: If the user asks about Admissions, Fees, Programs, Hostels, etc., provide accurate, concise information based on university data.
2. **General Queries**: If the user asks **ANY other question** (General knowledge, coding, science, chit-chat, etc.), you MUST answer it helpfully and accurately. **DO NOT REFEREE OR REFUSE.**

Response Guidelines:
- Be **friendly, polite, and professional**.
- Keep answers **concise** (2-3 sentences for simple questions, bullet points for complex ones).
- Use a **mix of Urdu + simple Hinglish** for a student-friendly tone where appropriate.
- NEVER say "I can only answer university questions". You are a general AI assistant now.

User Question: {user_input}

Respond concisely to help the student.
"""

        response = model.generate_content(prompt)
        return response.text.strip()

    except Exception as e:
        print("Gemini Error:", e)
        return "Maaf kijiye, main abhi is ka jawab nahi de sakta. Kya aap kisi aur program ki info chahte hain?"

def get_local_response(intent):
    for item in intents["intents"]:
        if item["tag"] == intent:
            return item["responses"][0]
    return "Maaf kijiye, is ka data available nahi hai."

def save_chat(user_input, bot_response, intent, confidence):
    conn = sqlite3.connect("database/unibot.db")
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO chats (user_input, bot_response, intent, confidence)
        VALUES (?, ?, ?, ?)
    """, (user_input, bot_response, intent, confidence))
    conn.commit()
    conn.close()

def save_low_confidence(user_input, intent, confidence):
    conn = sqlite3.connect("database/unibot.db")
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO low_confidence_logs (user_input, predicted_intent, confidence)
        VALUES (?, ?, ?)
    """, (user_input, intent, confidence))
    conn.commit()
    conn.close()

def get_previous_response(user_input):
    conn = sqlite3.connect("database/unibot.db")
    cursor = conn.cursor()
    cursor.execute("SELECT bot_response FROM chats WHERE user_input = ?", (user_input,))
    row = cursor.fetchone()
    conn.close()
    return row[0] if row else None


@app.route("/chat", methods=["POST"])
def chat():
    try:
        user_input = request.json.get("message", "").strip()
        
        if not user_input:
            return jsonify({
                "user_input": "",
                "intent": "greetings",
                "response": "Kya aap kisi program ki info chahte hain?",
                "confidence": 0.0,
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })

        try:
            intent, confidence = predict(user_input)
            print(f"[PREDICT] Input: '{user_input}' → Intent: {intent}, Confidence: {confidence:.2f}")
        except Exception as e:
            print(f"[ERROR] Prediction failed: {e}")
            response = call_gen_ai(user_input)
            save_chat(user_input, response, "error", 0.0)
            return jsonify({
                "user_input": user_input,
                "intent": "error",
                "error_details": str(e),
                "response": response,
                "confidence": 0.0,
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })

        CONF_THRESHOLD = 0.20

        if confidence < CONF_THRESHOLD:
            print(f"[FALLBACK] Low confidence ({confidence:.2f}) → Using Gemini")
            save_low_confidence(user_input, intent, round(confidence, 2))

            cached = get_previous_response(user_input)
            if cached:
                print(f"[CACHE] Using cached response")
                response = cached
            else:
                print(f"[GEMINI] Calling Gemini API")
                response = call_gen_ai(user_input)

        else:
            print(f"[LOCAL] High confidence ({confidence:.2f}) → Using local response")
            response = get_local_response(intent)

        save_chat(user_input, response, intent, round(confidence, 2))

        return jsonify({
            "user_input": user_input,
            "intent": intent,
            "response": response,
            "confidence": round(confidence, 2),
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
    
    except Exception as e:
        print(f"[CRITICAL ERROR] {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "user_input": user_input if 'user_input' in locals() else "",
            "intent": "error",
            "response": "Maaf kijiye, kuch technical issue hai. Kya aap dobara try kar sakte hain?",
            "confidence": 0.0,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/admin/intents")
def admin_intents():
    conn = sqlite3.connect("database/unibot.db")
    cursor = conn.cursor()
    cursor.execute("SELECT id, tag, patterns, responses FROM intents")
    rows = cursor.fetchall()
    conn.close()
    return render_template("admin_intents.html", intents=rows)

if __name__ == "__main__":
    if check_prerequisites():
        print("🚀 Starting Mini Bot server...")
        app.run(debug=True)
    else:
        print("❌ Cannot start server. Please fix the issues above.")
