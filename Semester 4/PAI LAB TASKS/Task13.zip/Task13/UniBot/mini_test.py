import os
from dotenv import load_dotenv
import google.generativeai as genai

load_dotenv()
api_key = os.getenv("GEMINI_API_KEY")
print(f"API Key found: {bool(api_key)}")

if not api_key:
    print("No API Key!")
    exit(1)

genai.configure(api_key=api_key)

try:
    print("Creating GenerativeModel...")
    model = genai.GenerativeModel("gemini-flash-latest")
    print("Model created.")
    
    print("Generating content...")
    response = model.generate_content("Hello")
    print(f"Response: {response.text}")
except Exception as e:
    print(f"ERROR: {e}")
