"""
Quick Test Script for UniBot
Tests the NLP prediction functionality
"""

from nlp_model.predict import predict

# Test cases with expected intents
test_cases = [
    ("hello", "greetings"),
    ("hi bot", "greetings"),
    ("how to apply for admission", "admission_process"),
    ("admission kaise karen", "admission_process"),
    ("what is eligibility criteria", "eligibility"),
    ("fee structure kya hai", "fee_structure"),
    ("what programs are offered", "programs_offered"),
    ("hostel facility available", "hostel_info"),
    ("scholarship available", "scholarships"),
    ("contact number kya hai", "contact_info"),
]

print("=" * 60)
print("UniBot NLP Model Test Results")
print("=" * 60)
print()

correct = 0
total = len(test_cases)

for user_input, expected_intent in test_cases:
    # Get prediction (no threshold parameter needed)
    predicted_intent, confidence = predict(user_input)
    is_correct = predicted_intent == expected_intent
    
    if is_correct:
        correct += 1
        status = "✅ PASS"
    else:
        status = "⚠️  WRONG"
    
    print(f"{status}")
    print(f"  Input: '{user_input}'")
    print(f"  Expected: {expected_intent}")
    print(f"  Predicted: {predicted_intent} (Confidence: {confidence:.2%})")
    print()

print("=" * 60)
print(f"Accuracy: {correct}/{total} ({correct/total*100:.1f}%)")
print("=" * 60)
