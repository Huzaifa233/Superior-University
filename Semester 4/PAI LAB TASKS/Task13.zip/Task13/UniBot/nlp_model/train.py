import pandas as pd
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

df = pd.read_csv("data/faq_data.csv")

df.columns = df.columns.str.strip()

df = df.dropna(subset=["pattern", "tag"])
df = df[df["pattern"].str.strip() != ""]
df = df[df["tag"].str.strip() != ""]

print(f"Loaded {len(df)} training examples")

X = df["pattern"]  
y = df["tag"]       

vectorizer = TfidfVectorizer(
    ngram_range=(1, 3),           
    analyzer='word',
    max_features=500,             
    min_df=1,                     
    sublinear_tf=True             
)

X_vec = vectorizer.fit_transform(X)

model = LogisticRegression(
    max_iter=3000,
    class_weight='balanced',      
    C=1.0,                       
    random_state=42
)
model.fit(X_vec, y)

import joblib
joblib.dump({
    "vectorizer": vectorizer,
    "model": model
}, "nlp_model/model.pkl")

print("🎉 Model trained successfully!")
