
import joblib
import numpy as np

try:
    data = joblib.load("nlp_model/model.pkl")
    
    vectorizer = data["vectorizer"]
    model = data["model"]
    label_encoder = data.get("label_encoder", None)
except FileNotFoundError:
    print("❌ Error: Model file not found!")
    print("Please train the model first by running: python nlp_model/train.py")
    raise
except Exception as e:
    print(f"❌ Error loading model: {e}")
    raise


def predict(user_input):
    """
    Predict the intent of a user input.
    Returns:
        intent (str) - predicted intent tag
        confidence (float) - probability of predicted intent (0.0 to 1.0)
    
    Note: This function always returns the model's prediction.
    The calling code should decide whether to use it based on confidence.
    """
    
    user_input = user_input.strip().lower()
    if not user_input:
        return "greetings", 0.0

 
    X = vectorizer.transform([user_input])
    
    
    probs = model.predict_proba(X)[0]
    idx = np.argmax(probs)
    confidence = probs[idx]

    
    if label_encoder:
        intent = label_encoder.inverse_transform([idx])[0]
    else:
        intent = model.classes_[idx]

    return intent, confidence

if __name__ == "__main__":
    print("✅ NLP Predict Ready. Type your message below:")
    while True:
        user_input = input("You: ").strip()
        if not user_input:
            continue
        intent, confidence = predict(user_input)
        print(f"Intent: {intent}, Confidence: {confidence:.2f}")
