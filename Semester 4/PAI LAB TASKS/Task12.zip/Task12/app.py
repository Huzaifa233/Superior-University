from flask import Flask, render_template, request, jsonify
import pandas as pd
import faiss
from sentence_transformers import SentenceTransformer
import numpy as np
import random

app = Flask(__name__)

# ------------------------------
# Load dataset
# ------------------------------
df = pd.read_csv("dataset.csv")  # Your CSV with 'Question' and 'Answer' columns

# Preprocess questions
questions = df['Question'].tolist()
answers = df['Answer'].tolist()

# ------------------------------
# Embedding model
# ------------------------------
model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')

# Compute embeddings for questions
question_embeddings = model.encode(questions, convert_to_numpy=True)

# ------------------------------
# FAISS setup
# ------------------------------
dimension = question_embeddings.shape[1]
index = faiss.IndexFlatL2(dimension)  # L2 distance
index.add(question_embeddings)

# ------------------------------
# Helper function to get response
# ------------------------------
def get_answer(user_input, k=1):
    user_embedding = model.encode([user_input], convert_to_numpy=True)
    distances, indices = index.search(user_embedding, k)
    best_idx = indices[0][0]
    best_answer = answers[best_idx]
    # If multiple answers separated by "/", pick randomly
    if "/" in best_answer:
        return random.choice([a.strip() for a in best_answer.split("/")])
    return best_answer

# ------------------------------
# Flask routes
# ------------------------------
@app.route("/")
def home():
    return render_template("index.html")

@app.route("/ask", methods=["POST"])
def ask():
    user_message = request.form['message']
    answer = get_answer(user_message)
    return jsonify({"answer": answer})

# ------------------------------
# Run Flask
# ------------------------------
if __name__ == "__main__":
    app.run(debug=True)
